# Senai Assefa
# ITP 216, Fall 2022
# Section: 32081
# Project
# Description:
# Analyzing the stats of each soccer player from diffirent countries across world cups

import sqlite3 as sl
import pandas as pd
from flask import Flask, redirect, render_template, request, url_for
from matplotlib import pyplot as plt
app = Flask(__name__)
from flask import Flask, redirect, render_template, request, session, url_for
import os
import sqlite3 as sl


# select a country, then select a world cup and stat category, show the players with the highest in those stats in order
# from that country and from that world cup
# Instead of year can filter by position for each stat
# NEED SOME TYPE OF CALCULATION


@app.route("/")
def home():
    return redirect(url_for("select_country"))

@app.route("/select_country", methods=["GET", "POST"])
def select_country():
    if request.method == "POST":
        userNationality = request.form["nationality"]
        result = db_check_country(userNationality)
        if result == True:
           return render_template("select_stat.html")
        else:
           return redirect(url_for("select_country"))

    else:
        return render_template("select_country.html")


# this is going to be a tab
@app.route("/select_stat", methods=["GET", "POST"])
def select_stat():
    if request.method == "POST":
        userStat = request.form["stat"]
        result = db_check_stat(userStat)
        if result == True:
            # this is supposed to be the graph
           return render_template("rankings_of_players", message="Please Select A Stat Category")
        else:
            redirect(url_for("select_country"))


# this is also going to be a tab
@app.route("/select_stat", methods=["GET", "POST"])
def select_position():
    if request.method == "POST":
        userPosition = request.form["position"]
        result = db_check_position(userPosition)
        if result == True:
            render_template("/select_stat")
        else:
            return redirect(url_for("/select_country"))


# the graph I am going to be making of all the highest stats from
# def stats:


def db_check_country(nationality):
    conn = sl.connect('soccer.db')
    curs = conn.cursor()
    v1 = (nationality,)
    # select the countries column from the nations table
    stm1 = "SELECT nationality FROM rankings WHERE nationality = ?"
    data = curs.execute(stm1, v1)
    for result in data:
        if result[0] == nationality:
            return True
        else:
            return False


def db_check_stat(stat):
    conn = sl.connect('soccer.db')
    curs = conn.cursor()
    v1 = (stat,)
    # seeing if the name is a column header help from here
    stm1 = "SELECT * FROM data WHERE stat = ?"
    data = curs.execute(stm1, v1)


def db_check_position(role):
    conn = sl.connect("soccer.db")
    curs = conn.cursor()
    v1 = (role,)
    stm1 = "SELECT position FROM DATA WHERE role = ?"
    data = curs.execute(stm1, v1)
    for result in data:
        if result[0] == role:
            return True
        else:
            return False


if __name__ == "__main__":
        # Unit test of db_get_user_list()


        # Start flask app
    app.secret_key = os.urandom(12)
    app.run(debug=True)


# creating a database
# have to include position of each of the players
# def creating_database():
conn = sl.connect("soccer.db")
curs = conn.cursor()
curs.execute('CREATE TABLE IF NOT EXISTS info (`nationality` text, `position` text,`height` number, `overall` number, `potential` number, `wage` number, `value` number, `weakffoot` number, `pace` number, `shooting` number, `dribbiling` number, `defending` number, `physcial` number, `gk_handling` number, `gk_kicking` number, `gk_reflexes` number, `gk_speed` number, `gk_positioning` number, `crossing` number, `finishing` number, `heading` number, `volley` number, `curve` number, `long_passing` number, `ball control` number, `acceleration` number, `sprint_speed` number, `agility` number, `balance` number, `reactions` number, `long_shot` number, `agression` number, `strength` number, `interception` number, `penalties` number, `standing_tackle` number, `sliding_tackle` number)')
conn.commit()

df = pd.read_csv('players_20.csv', usecols=['nationality', 'position', 'height', 'overall', 'potential', 'wage', 'value', 'weakffoot', 'pace', 'shooting', 'dribbiling', 'defending', 'physcial', 'gk_handling', 'gk_kicking', 'gk_reflexes', 'gk_speed', 'gk_positioning', 'crossing', 'finishing', 'heading', 'volley', 'curve', 'long_passing', 'ball control', 'acceleration', 'sprint_speed', 'agility','balance', 'reactions', 'long_shot', 'agression', 'strength', 'interception', 'penalties', 'standing_tackle', 'sliding_tackle'])
df.to_sql(name='players_20', con=conn, if_exists='replace', index=False)

df = df[df["pace"].notnull()]
df = df[df["shooting"].notnull()]
df = df[df["dribbling"].notnull()]
df = df[df["physic"].notnull()]
df = df[df["gk_diving"].notnull()]
df = df[df["gk_handling"].notnull()]
df = df[df["gk_kicking"].notnull()]
df = df[df["gk_reflexes"].notnull()]
df = df[df["gk_speed"].notnull()]
df = df[df["gk_positioning"].notnull()]







# df.to_sql(name='data', con=conn, if_exists='replace', index=False)
#
# # dataframe and Pandas Work
# # def creatin graph
# fig, ax = plt.subplots(1, 1)
# df = pd.read_csv("players_20.csv")
# # am i making every stat column that I am using in my csv not null then
# df = df[df[]]
# # making barplot
# # goal is to group by country, stat, then position
# df_country = df.grouby("nationality")
# # question here
# df_stat = df.groupby(selected
# stat)
# df_position = df.grouby("player_positions")

# machine learning stuff
